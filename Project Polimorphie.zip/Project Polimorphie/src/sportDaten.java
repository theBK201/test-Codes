import org.omg.CosNaming.NamingContextExtPackage.StringNameHelper;

import java.util.LinkedList;

public class sportDaten {
    protected String sportlerName;
    protected String line = "----------------";

    public sportDaten(String n){
        sportlerName = n;
    }


     void display(){
        System.out.println("ready for override");
    }
}
