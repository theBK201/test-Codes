import java.util.LinkedList;

public class printSportDaten {
    public static void main(String[] args) {
        LinkedList<sportDaten> sportDt = new LinkedList<>();

        sportDt.add(new Marathon("Markus",5,40,12));
        sportDt.add(new SpeerWurf("Daniel",30.23));
        sportDt.add(new Sprint100m("Max",9,45));

        for(int i=0; i<sportDt.size();i++){
            sportDt.get(i).display();
            System.out.println(sportDt.get(i).line);
        }
    }
}
